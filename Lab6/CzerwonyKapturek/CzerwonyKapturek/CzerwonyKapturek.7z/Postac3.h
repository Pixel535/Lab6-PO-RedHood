#pragma once
class Postac3
{
public:

	virtual void przedstawia(int wyb) = 0;
};

