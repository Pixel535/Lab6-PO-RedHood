#pragma once
#include "Mama.h"
class Mama
{
public:
	void wyslala();
	void wrecza();
	void przestrzega();
};

