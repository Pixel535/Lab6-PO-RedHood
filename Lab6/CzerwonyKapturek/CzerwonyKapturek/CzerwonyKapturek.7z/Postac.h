#pragma once
class Postac
{
public:

	virtual void wyrusza(int wyb) = 0;
	virtual void dochodzi() = 0;
	virtual void pyta(int wyb) = 0;
};

