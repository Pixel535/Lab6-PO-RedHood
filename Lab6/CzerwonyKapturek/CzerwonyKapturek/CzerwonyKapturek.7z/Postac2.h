#pragma once
#include <iostream>
class Postac2
{
public:

	void wyskakuje()
	{
		std::cout << "W tym momencie wyskoczyla z niego babcia, a zaraz potem Czerwony Kapturek!" << std::endl;
	}
	void cieszy_sie()
	{
		std::cout << "babcia i Czerwony Kapturek cieszyli si�, �e wszystko skonczylo sie dla nich dobrze. " << std::endl;
	}
	
};

