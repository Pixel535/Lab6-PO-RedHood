#pragma once
#include "Postac2.h"
#include <iostream>

class Babcia :public Postac2
{
public:

	void zaprasza();
	void pyta();
	

};

