#include "Mama.h"
#include <iostream>

void Mama::przestrzega()
{
	std::cout << "Pamietaj tylko, bys pod zadnym pozorem nie zbaczala ze sciezki, ktora znasz i wiesz, " << std::endl;
	std::cout << "ze prowadzi prosto do domku babci.Jesli kogos spotkasz, nie rozmawiaj z nim." << std::endl;
	std::cout << "Gdy juz tam bedziesz, przywitaj sie ladnie z babunia i badz grzeczna.\n" << std::endl;
}

void Mama::wrecza()
{
	std::cout << "Jednego razu mama zawolala Czerwonego Kapturka oraz wreczyla mu wiklinowy " << std::endl;
	std::cout << "koszyk przykryty serwetka, do ktorego schowala ciasto i butelke wina, mowiac:" << std::endl;
}

void Mama::wyslala()
{
	std::cout << "- Coreczko, zanies to babuni, zeby nabrala sil. Od jakiegos czasu lezy biedna chora w lozku. " << std::endl;
	std::cout << "Na pewno ucieszy sie, kiedy ja odwiedzisz. " << std::endl;
}