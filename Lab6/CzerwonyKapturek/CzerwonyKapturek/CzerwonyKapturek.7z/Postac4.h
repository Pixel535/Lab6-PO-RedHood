#pragma once
class Postac4
{
public:

	virtual void widzi() = 0;
};

