#include "Narrator.h"

void Narrator::konczy()
{
	std::cout << "Nastepnie Czerwony kapturek wesolo wrocil do domu. Bajka Czerwony Kapturek powstala na podstawie basni braci Grimm." << std::endl;
}