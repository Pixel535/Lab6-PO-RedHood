#include "Babcia.h"

void Babcia::pyta()
{
	std::cout << " wi�c babcia zawo�a�a:" << std::endl;
	std::cout << "- Kto tam?" << std::endl;
}

void Babcia::zaprasza()
{
	std::cout << "- Wejdz, kochana wnusiu!- odparla babcia." << std::endl;
}